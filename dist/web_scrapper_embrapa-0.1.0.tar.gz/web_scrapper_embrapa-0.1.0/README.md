# Web Scrapper Emprapa

Web Scrapper que extrai dados do site da embrapa para curso FIAP

## Licença
Distribuído sob a licença MIT. Veja arquivo "licencse.txt" para maiores informações.